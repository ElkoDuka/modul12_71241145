import streamlit as st
import pandas as pd
from google import genai
import json
import re
import matplotlib.pyplot as plt

client = genai.Client(api_key="AQ.Ab8RN6L0unO6qeE1pWSnCqTaFsK5ILm227xRNdDOk8HzDnkSlA")

st.title("Analisis Nilai Mahasiswa Menggunakan Gemini AI (JSON Version)")

uploaded_file = st.file_uploader("Upload file CSV data nilai mahasiswa", type=["csv"])

if uploaded_file is not None:
    # Baca data CSV
    df = pd.read_csv(uploaded_file)
    st.write("Data Nilai Mahasiswa:")
    st.dataframe(df.head())

    text_data = df.to_string(index=False)

    # Prompt untuk analisis dan output JSON
    prompt = f"""
    Analisis data nilai mahasiswa berikut:
    {text_data}

    1. Hitung nilai maksimum, minimum, dan rata-rata.
    2. Temukan pola menarik dari distribusi nilai.
    3. Berikan observasi tentang performa kelas.
    4. Berikan rekomendasi untuk meningkatkan performa kelas.
    5. Kirimkan hasil analisis dalam format JSON valid.
    6. Jangan berikan teks atau penjelasan tambahan di luar JSON.
    Contoh format output:
    {{
        "maksimum": 95,
        "minimum": 45,
        "rata_rata": 72.5,
        "pola": "Sebagian besar nilai berada di kisaran 60-80",
        "observasi": "Performa kelas cukup baik dengan beberapa siswa berprestasi tinggi",
        "rekomendasi": "Fokus pada siswa dengan nilai di bawah rata-rata untuk peningkatan"
    }}
    """

    with st.spinner("Sedang mengirim data ke Gemini dan menunggu hasil analisis..."):
        # Panggil model Gemini
        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=prompt
        )

    # Bersihkan respons agar hanya tersisa isi JSON
    raw_text = response.text.strip()
    json_match = re.search(r"\{.*\}", raw_text, re.DOTALL)
    json_text = json_match.group(0) if json_match else raw_text

    try:
        # Parsing JSON dari hasil Gemini
        hasil = json.loads(json_text)
        st.subheader("Hasil Analisis Nilai Mahasiswa")

        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Nilai Maksimum", hasil['maksimum'])
        with col2:
            st.metric("Nilai Minimum", hasil['minimum'])
        with col3:
            st.metric("Nilai Rata-rata", hasil['rata_rata'])

        st.write(f"**Pola:** {hasil['pola']}")
        st.write(f"**Observasi:** {hasil['observasi']}")
        st.write(f"**Rekomendasi:** {hasil['rekomendasi']}")

        # Buat grafik distribusi nilai
        st.subheader("Grafik Distribusi Nilai Mahasiswa")
        fig, ax = plt.subplots()
        ax.hist(df['Nilai'], bins=10)
        ax.set_xlabel("Rentang Nilai")
        ax.set_ylabel("Jumlah Mahasiswa")
        ax.set_title("Distribusi Nilai Mahasiswa")
        st.pyplot(fig)

    except json.JSONDecodeError:
        st.error("Gagal membaca hasil JSON dari Gemini. Format tidak valid.")
    except Exception as e:
        st.error(f"Terjadi kesalahan: {e}")
else:
    st.info("Silakan unggah file CSV terlebih dahulu.")
