import google.generativeai as genai
import streamlit as st
import pandas as pd
import requests
import matplotlib.pyplot as plt

GEMINI_API_KEY = "AQ.Ab8RN6L0unO6qeE1pWSnCqTaFsK5ILm227xRNdDOk8HzDnkSlA"
genai.configure(api_key=GEMINI_API_KEY)


def get_weather_data(lat, lon, start_date, end_date):
    url = "https://archive-api.open-meteo.com/v1/archive"
    params = {
        "latitude": lat,
        "longitude": lon,
        "start_date": start_date.strftime("%Y-%m-%d"),
        "end_date": end_date.strftime("%Y-%m-%d"),
        "daily": "temperature_2m_max",
        "timezone": "Asia/Jakarta"
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
    response = requests.get(url, params=params, headers=headers)
    if response.status_code != 200 or not response.text.strip():
        st.error(f"Error dari server Open-Meteo (Kode: {response.status_code}): {response.text}")
        st.stop()
    data = response.json()
    df = pd.DataFrame({
        "Tanggal": data["daily"]["time"],
        "Suhu Maksimum (°C)": data["daily"]["temperature_2m_max"]
    })
    return df



def analyze_weather_with_gemini(df):
    text_data = df.to_string(index=False)

    prompt = f"""
    Berikut data suhu maksimum harian selama periode pengamatan:
    {text_data}

    Buat analisis tren suhu dan prediksi kondisi suhu 7 hari ke depan.
    Jawab dalam format JSON dengan field:
    - tren (naik/turun/stabil)
    - prediksi (ringkasan singkat)
    - alasan (penjelasan)
    """

    model = genai.GenerativeModel("models/gemini-3.8-flash")
    response = model.generate_content(prompt)
    return response.text

st.title("Prediksi Tren Cuaca dengan Gemini AI")
st.markdown("Aplikasi ini mengambil data cuaca dari [Open-Meteo](https://open-meteo.com) \
dan mengirimkannya ke **Gemini AI** untuk mendapatkan analisis tren dan prediksi suhu.")

city = st.text_input("Kota", "Yogyakarta")
lat = st.number_input("Latitude", value=-7.7972, format="%.4f")
lon = st.number_input("Longitude", value=110.3688, format="%.4f")
start_date = st.date_input("Tanggal Mulai", pd.to_datetime("2025-09-24"))
end_date = st.date_input("Tanggal Akhir", pd.to_datetime("2025-10-24"))

if st.button("Ambil dan Analisis Data"):
    with st.spinner("Mengambil data cuaca..."):
        df = get_weather_data(lat, lon, start_date, end_date)
    st.success("Data berhasil diambil!")
    st.dataframe(df)

    st.subheader("Grafik Suhu Harian")
    fig, ax = plt.subplots()
    ax.plot(df["Tanggal"], df["Suhu Maksimum (°C)"], marker='o')
    ax.set_xlabel("Tanggal")
    ax.set_ylabel("Suhu Maksimum (°C)")
    ax.set_title(f"Pergerakan Suhu Harian di {city}")
    plt.xticks(rotation=45)
    st.pyplot(fig)

    with st.spinner("Mengirim data ke Gemini AI..."):
        result = analyze_weather_with_gemini(df)
    st.subheader("Hasil Analisis AI")
    st.write(result)
